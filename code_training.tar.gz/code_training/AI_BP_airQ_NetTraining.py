# -*- coding: utf-8 -*-
"""
Created on Sun Oct  8 18:34:47 2023

@author: zhangzy
"""
import time
import datetime
import os
import numpy as np
import pandas as pd
import scipy.io as sio
import matplotlib
import matplotlib.pyplot as plt
import pickle
import shutil
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras import optimizers
from keras.optimizers import adam_v2
from sklearn import datasets
from sklearn import preprocessing
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error

#############################################
#############################################
def BPmodel(inputX,outputY,var,vv,netpath,figpath,city,inputX_ave,inputX_std,outputY_ave,outputY_std):
    #########
    #########
    # inputX = data['input']
    # outputY = data['output']
    
    #########
    # input_train = data['input_train'].T
    # output_train = data['output_train'].T 
    
    # input_test = data['input_test'].T
    # output_test = data['output_test'].T
    
    
    #########
    #########
    #input_train,input_test,output_train,output_test = train_test_split(input,output,test_size=0.2,random_state=1)
    input_train,input_test,output_train,output_test = train_test_split(inputX,outputY,test_size=0.2,random_state=0)
    
    ######### special for BP 
    y = output_train.ravel()

    #########
    ######### some parameters
    lr = 0.001 
    max_epochs = 200 
    n_hidden = 20 
    in_features = input_train.shape[1]
    out_features = output_train.ndim
    
    ADAM = optimizers.adam_v2.Adam(learning_rate=lr)  
    
    #########
    ######### build BPNetModel
    model = Sequential()
    model.add(Dense(64, input_dim=in_features, activation='relu'))
    model.add(Dropout(rate=0.2))
    model.add(Dense(32, activation='relu')) 
    model.add(Dropout(rate=0.2))
    model.add(Dense(1))

    #########
    ######### compile model
    model.compile(loss='mean_squared_error', optimizer=ADAM, metrics=['mse'])
        
    ######### initial parameters
    model.fit(input_train, output_train, epochs=max_epochs,batch_size=32, verbose=2)
    
    ######### eval
    test_loss, test_acc = model.evaluate(input_test, output_test, verbose=0)
    print('Test loss:', test_loss) 
    print('Test accuracy:', test_acc)

    #########
    print('99999999999')

    #########
    ######### save net
    netpathNew = netpath+'/'+var+'_'+city
    if os.path.isdir(netpathNew):
       print(netpathNew+' already exist, pls remove it first, and then create it')
       shutil.rmtree(netpathNew)
       #os.rmdir(netpathNew)
       os.mkdir(netpathNew)
    else:
       print(netpathNew+' does not exist, pls create it directedly')
       os.mkdir(netpathNew)
    #########
    model.save(netpathNew) 
    
    
    #########
    ######### save model
    #f = open(netpath+'/model.pickle.'+var+'_'+city,'wb')
    #pickle.dump(model,f)
    #f.close()
    
    #########
    ######### test
    y_test = output_test # obs
    y_mod = input_test[:,vv];
    y_pred = model.predict(input_test)
    ###
    y_pred = y_pred.ravel()
    
   
    #########
    ######### reverse to normal data
    y_test = outputY_ave + y_test*outputY_std
    y_pred = outputY_ave + y_pred*outputY_std
    y_mod  = inputX_ave[vv] + y_mod*inputX_std[vv]
    
    #########
    #########
    print('the type of y_pred is '+str(type(y_pred)))
    #y_pred = y_pred.T
    #y_pred = y_pred.reshape(240,1)
    
    kk = y_pred.size
    print('the size of y_pred is kk='+str(kk))
    #print(y_pred)
    
    ll = y_test.size
    print('the type of y_test is '+str(type(y_test)))
    print('the size of y_test is ll='+str(ll))
    #print(y_test)
    
    #########
    ######### check corr
    corr_Obs_BP = np.corrcoef(y_test, y_pred)
    print('corr_Obs_BP=', str(corr_Obs_BP[0,1]))
    
    corr_Obs_Mod = np.corrcoef(y_test, y_mod)
    print('corr_Obs_Mod=', str(corr_Obs_Mod[0,1]))
    
    #########
    ######### check rmse
    rmse_Obs_BP = np.sqrt(mean_squared_error(y_test, y_pred))
    print('rmse_Obs_BP=', rmse_Obs_BP)
    
    rmse_Obs_Mod = np.sqrt(mean_squared_error(y_test, y_mod))
    print('rmse_Obs_Mod=', rmse_Obs_Mod)
    
    #########
    #########
    # accuracy = accuracy_score(y_test,y_pred)
    #accuracy = explained_variance_score(y_test,y_pred)
    #print("accuarcy: %.2f%%" % (accuracy*100.0))
    
###########################
########################### 
lags = [3, 6, 9, 12, 18, 24]  # in hours
def add_time_lags(inputX, lags):  
    n_samples, n_features = inputX.shape  
    max_lag = max(lags)  
    
    #  
    lagged_features = []  
    
    # loop wach lag time  
    for lag in lags:  
        #   
        lagged = np.roll(inputX, shift=lag, axis=0)  
        lagged[:lag, :] = np.nan  #   
        lagged_features.append(lagged)  
    
    #  
    inputX_with_lags = np.hstack([inputX] + lagged_features)  
    
    #   
    # inputX_with_lags = inputX_with_lags[max_lag:, :]  
    
    return inputX_with_lags 


##############################################
##############################################
########
def CitiesINFO(city,datapath):
    print('city='+city)
    print('preapare data for doing AI learning')  
    fname = "xdata_mod_obs_"+city+"_since2021.mat"
    data = sio.loadmat(datapath+"/"+fname)
    #########
    #########
    xmod = data['xmod_hourly_Fday1_'+city]
    xobs = data['xobs_hourly_'+city]
    allhours = data['allhours']
    
    #########
    ######### VIP, only data before 2023.08 have been used for training
    mask = (allhours[:, 0] < 2023) | ((allhours[:, 0] == 2023) & (allhours[:, 1] < 8))
    xmod = xmod[mask, :]
    xobs = xobs[mask, :]
    allhours = allhours[mask, :]
    print(allhours.shape) 
    print(xmod.shape) 

    ######### get the var_xmod to list
    nn = data['var_xmod'].shape[1]
    var_xmod = list()
    for ii in range(0,nn):
        tmp = data['var_xmod'][0,ii][0]
        #print('ii='+str(ii)+':'+tmp)
        tmp = tmp.split(" ")
        var_xmod.append(tmp)
    
    ######### get the var_xobs to list
    nn = data['var_xobs'].shape[1]
    var_xobs = list()
    for ii in range(0,nn):
        tmp = data['var_xobs'][0,ii][0]
        #print('ii='+str(ii)+':'+tmp)
        tmp = tmp.split(" ")
        var_xobs.append(tmp)
    
    
    #########    
    ######### convert unit of co to mg/m3 in xobs
    idx = var_xobs.index(['co'])
    xobs[:,idx] =  xobs[:,idx]/1000
    
    #########    
    ######### convert unit of vis to km in xobs
    idx = var_xobs.index(['vis'])
    xobs[:,idx] =  xobs[:,idx]/1000   
 
    ########
    #for vv in [0,1,2,3,4,5,6]:
    # only for pm2.5 and vis
    for vv in [0,6]:
        print('vv='+str(vv))
        varX=['pm25','pm10','so2','no2','co','o3','vis']
        var=varX[vv]
        print(varX[vv])
        
        #########  
        #########
        inputX = xmod
        print("size of the raw inputX:", inputX.shape)
        
        #########
        ######### time-lagged
        inputX = add_time_lags(inputX, lags) 
        print("size of the new inputX:", inputX.shape)
       
        #########  
        ######### get prediction bias  
        idx = var_xmod.index([var])
        print('idx='+str(idx))
        outputY = xmod[:,idx]-xobs[:,vv]
        
        #########
        #########  VIP
        outputY=outputY.reshape(outputY.shape[0],1)
        
        ######### together         
        dataXY = np.concatenate((inputX, outputY),axis=1)
        
        ######### remove the time with the NaN records
        dataXY = dataXY[~np.isnan(dataXY).any(axis=1)]
       
        #########
        ######### to check and ensure no training test for citis without any obs or mode data
        ######### or the number of the valid sample is too little
        dataXY_ave = np.nanmean(dataXY,axis=0)
        dataXY_ave_all = np.mean(dataXY_ave)
            
        if np.isnan(dataXY_ave_all) or dataXY.shape[0]<1000:
            print('there is no any valid data in obs or/and mod data,or the No. of sample is too little, so there is no need to try AI training for '+city)
        else:
            print('the data appears to be valid, so pls have a try to AI training for '+city)
        
            #########
            #########
            inputX = dataXY[:,0:-1]
            outputY = dataXY[:,-1]   
        
            #########
            ######### normalize, ano/std
            inputX_ave = np.mean(inputX,axis=0)
            inputX_std = np.std(inputX,axis=0)
            inputX_ano = inputX - inputX_ave
            inputX_nor = inputX_ano/inputX_std
    
            outputY_ave = np.mean(outputY,axis=0)
            outputY_std = np.std(outputY,axis=0)
            outputY_ano = outputY - outputY_ave
            outputY_nor = outputY_ano/outputY_std
    
            #########
            ######### save normalize parameters for prediction
            sio.savemat(netpath+'/norm_parameter_'+var+'_'+city+'.mat',{'inputX_ave':inputX_ave,'inputX_std':inputX_std,'outputY_ave':outputY_ave,'outputY_std':outputY_std})
    
            #########  
            ######### training
            inputX = inputX_nor
            outputY = outputY_nor
            
            #########
            BPmodel(inputX,outputY,var,vv,netpath,figpath,city,inputX_ave,inputX_std,outputY_ave,outputY_std)
        
            ##########
            utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
            print('finised of running AI_BP_airQ_modelTrainX for '+var+' of '+city+' at utc='+utcnow)
            ##########

    ##########
    utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
    print('finised of running AI_BP_airQ_modelTrainX for '+city+' at utc='+utcnow)
    ##########

##############################################
############################
########
########
netpath="/data/yewu_RMAPSCHEM_MRv2/AI_TimeSeries/nets_tmp/BP"
figpath=netpath
########
datapath="/data/Data4AI/309CitiesNew"

#########
######### read cityINFO
CityName = sio.loadmat(datapath+'/CnameE.mat')  
CityNameE= CityName['CnameE']

#########
######### loop for training
for i in range(len(CityNameE)):
    #########
    city = str(CityNameE[i][0][0])  # 提取列表中的第一个元素（字符串）
    print(city)
    # 拼接文件名
    fname = "xdata_mod_obs_" + city + "_since2021.mat"
    print(fname)  # 打印文件名以检查是否正确   
    
    #########
    ### if plotF[i]==111:
    if  os.path.exists(datapath+"/"+fname):
        utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
        print('start running BP train for '+city+' at utc='+utcnow)
        ########
        CitiesINFO(city,datapath) 
    else:
        print('no needing to run BP train for '+city)

############################
############################
##########
utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
print('finised of running AI_BP_airQ_modelTrainX for all needed citie at utc='+utcnow)
##########
