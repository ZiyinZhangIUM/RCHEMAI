# -*- coding: utf-8 -*-
"""
Created on Sun Oct  8 18:34:47 2023

@author: zhangzy
"""

import os
import time
import datetime
import numpy as np
import pandas as pd
import scipy.io as sio
import matplotlib
import matplotlib.pyplot as plt
import pickle
import shutil
#from keras.models import Sequential
#from keras.layers import Dense
#from keras.layers import LSTM
from tensorflow import keras
#from tensorflow.python.keras.optimizers import adam_v2
#from keras.optimizers import adam_v2


###########################
########################### 
lags = [3, 6, 9, 12, 18, 24]  # in hours
def add_time_lags(inputX, lags):
    n_samples, n_features = inputX.shape
    max_lag = max(lags)
    
    #  
    lagged_features = []
    
    # loop wach lag time  
    for lag in lags:
        #   
        lagged = np.roll(inputX, shift=lag, axis=0)
        lagged[:lag, :] = np.nan  #   
        lagged_features.append(lagged)
    
    #  
    inputX_with_lags = np.hstack([inputX] + lagged_features)
    
    #   
    # inputX_with_lags = inputX_with_lags[max_lag:, :]  
    
    return inputX_with_lags


      
#############################################
#############################################         
def daysRange(beginDay, endDay):
    dates = []
    dt = datetime.datetime.strptime(beginDay, "%Y%m%d")
    date = beginDay[:]
    while date <= endDay:
        dates.append(date)
        dt = dt + datetime.timedelta(1)
        date = dt.strftime("%Y%m%d")
    return dates
        
#############################################
#############################################
def hoursRange(beginHour, endHour):
    Hours = []
    dt = datetime.datetime.strptime(beginHour, "%Y%m%d%H")
    hour = beginHour[:]
    while hour <= endHour:
        Hours.append(hour)
        dt = dt + datetime.timedelta(1/24)
        hour = dt.strftime("%Y%m%d%H")
    return Hours

  
##############################################
##############################################
########
def CitiesINFO(city,netpath,inputX_test,outpath,pallhourstr,dayCstrUTC):
    varP=['pm25','vis']
    #########
    YYout = np.zeros((len(inputX_test),len(varP)))
    #########
    for vv in [0,1]:
        print('vv='+str(vv))
        var=varP[vv]
        print(varP[vv])
        
        ######### load the AI model and norm_parameter
        ######### get the var_xmod to list
        netpathNew = netpath+'/'+var+'_'+city
        if os.path.exists(netpathNew):
            ######## load the model
            model = keras.models.load_model(netpathNew)
          
            ########
            ######## load the norm_parameters
            norm_param = sio.loadmat(netpath+'/norm_parameter_'+var+'_'+city+'.mat')
            inputX_ave = norm_param['inputX_ave']
            inputX_std = norm_param['inputX_std']
            outputY_ave = norm_param['outputY_ave']
            outputY_std = norm_param['outputY_std']
            
            
            #########  
            ######### normalize for inputX_test 
            inputX = inputX_test
            print('size of inputX:',inputX.shape)
            print('size of inputX_ave:',inputX_ave.shape)            

            inputX_ano = inputX - inputX_ave
            inputX_nor = inputX_ano/inputX_std
            
            #########
            ######### prediction
            ### speical for LSTM 
            inputX_nor2 = inputX_nor.reshape(inputX_nor.shape[0],1,inputX_nor.shape[1])
            inputX_nor = inputX_nor2            
            #########
            y_pred = model.predict(inputX_nor)
            print("size of y_pred:",y_pred.shape)           
 
            ######### reverse to normal data
            y_pred_bias = outputY_ave + y_pred*outputY_std
            y_pred_bias = y_pred_bias.T
            print("size of y_pred_bias:",y_pred_bias.shape)           
          
            # convert bias to actual value, = xmod + delta
            varZ=['pm25','pm10','so2','no2','co','o3','vis','rh2','t2','u10','v10','pblh','CLDFRA']
            idz = varZ.index(var)
            tmp=inputX[:, idz]
            y_pred_actual = tmp + y_pred_bias  
            print("size of y_pred_actual:",y_pred_actual.shape)           
            
            ######### extreme value limit
            if var == 'pm25':
                y_pred_actual = np.clip(y_pred_actual, 2, 500)
            elif var == 'vis':
                y_pred_actual = np.clip(y_pred_actual, 0.2, 30)
             
            ######### 
            print("size of y_pred_actual:",y_pred_actual.shape)           
            YYout[:,vv] = y_pred_actual

        else:
            print('sth wrong in getting net.pickle.'+var+'_'+city)

    ########## save 
    sio.savemat(outpath+'/AI_LSTM_airQ_'+city+'.mat',{'YYout':YYout,'varP':varP,'pallhourstr':pallhourstr}) 
    ##########
    utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
    print('finised of predicting airQ for '+city+' based on AI_LSTM_airQ_NetrainX model and RMAPSCHEM-MRv2 data in '+dayCstrUTC+' at utc='+utcnow)
    ##########

##############################################
############################################## TimesINFO
def TimesINFO(netpath,dayCstrUTC,pallhourstr):
    print('do predict for '+dayCstrUTC)
    #########  
    RMAPSChem_data_path='/data/Data4AI/RMAPSChem_prediction' 
    outpath="/data/yewu_RMAPSCHEM_MRv2/AI_TimeSeries/out_RMAPSChem_AI/"+dayCstrUTC
    if os.path.exists(outpath):
       print(outpath+' already exist')
    else:
       print(outpath+' does not exist, pls create it')
       os.mkdir(outpath)
    
    #########
    ######### cal dayP1strUTC
    dayC_datetime = datetime.datetime.strptime(dayCstrUTC, "%Y%m%d%H")
    dayP1_datetime = dayC_datetime - datetime.timedelta(days=1)
    dayP1strUTC = dayP1_datetime.strftime("%Y%m%d%H")
    print('dayP1strUTC='+dayP1strUTC)

    #########
    ######### first, the current and the previous data mod data should be existed!!!
    fRMAPSCHEM_dayC = RMAPSChem_data_path+'/'+dayCstrUTC+'/RMAPSCHEM_pred_309Cities.mat'
    fRMAPSCHEM_dayP1 = RMAPSChem_data_path+'/'+dayP1strUTC+'/RMAPSCHEM_pred_309Cities.mat'
    #########
    if os.path.exists(fRMAPSCHEM_dayC) and os.path.exists(fRMAPSCHEM_dayP1) :
       print(fRMAPSCHEM_dayC +' and '+ fRMAPSCHEM_dayP1+' exist, pls go on')
       AI_task = 'True'
    else:
       AI_task = 'False'
       print('so, the task of AI prediction can not be executed ~~~~~~~~')
    
    #########
    ######### loop for prediction
    if AI_task == 'False':
       print('none of '+fRMAPSCHEM_dayC+', '+fRMAPSCHEM_dayP1+' exist')
       print('so, the task of AI prediction can not be executed ~~~~~~~~')
    else:
       utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
       print('RMAPSChem data exist, start doing AI prediction at utc='+utcnow)
       ######## 
       ######## load the current RCHEM data
       dataC = sio.loadmat(fRMAPSCHEM_dayC)
       dataP1 = sio.loadmat(fRMAPSCHEM_dayP1)
       ######### get the YYpre data 
       varX=['pm25','pm10','so2','no2','co','o3','vis','rh2','t2','u10','v10','pblh','CLDFRA']
       varY=['YYpre_pm25','YYpre_pm10','YYpre_so2','YYpre_no2','YYpre_co','YYpre_o3','YYpre_vis','YYpre_rh2','YYpre_t2','YYpre_u10','YYpre_v10','YYpre_pblh','YYpre_CLDFRA']
       YYpre_pm25 = np.concatenate((dataP1['YYpre_pm25'][:24], dataC['YYpre_pm25']))
       YYpre_pm10 = np.concatenate((dataP1['YYpre_pm10'][:24], dataC['YYpre_pm10']))
       YYpre_so2 = np.concatenate((dataP1['YYpre_so2'][:24], dataC['YYpre_so2']))
       YYpre_no2 = np.concatenate((dataP1['YYpre_no2'][:24], dataC['YYpre_no2']))
       YYpre_co = np.concatenate((dataP1['YYpre_co'][:24], dataC['YYpre_co']))
       YYpre_o3 = np.concatenate((dataP1['YYpre_o3'][:24], dataC['YYpre_o3']))
       YYpre_vis = np.concatenate((dataP1['YYpre_vis'][:24], dataC['YYpre_vis']))
       YYpre_rh2 = np.concatenate((dataP1['YYpre_rh2'][:24], dataC['YYpre_rh2']))
       YYpre_t2 = np.concatenate((dataP1['YYpre_t2'][:24], dataC['YYpre_t2']))
       YYpre_u10 = np.concatenate((dataP1['YYpre_u10'][:24], dataC['YYpre_u10']))
       YYpre_v10 = np.concatenate((dataP1['YYpre_v10'][:24], dataC['YYpre_v10']))
       YYpre_pblh = np.concatenate((dataP1['YYpre_pblh'][:24], dataC['YYpre_pblh']))
       YYpre_CLDFRA = np.concatenate((dataP1['YYpre_CLDFRA'][:24], dataC['YYpre_CLDFRA']))

       #########
       ######### 
       for ic in range(len(CityNameE)):
           city = CityNameE[ic][0][0]
           print('city: '+city)
           #########
           ######### inputX_test for each city
           inputX_test = np.zeros((len(YYpre_pm25),len(varY)))
           
           #########
           idx=ic
           inputX_test[:,0]=YYpre_pm25[:,idx]
           inputX_test[:,1]=YYpre_pm10[:,idx]
           inputX_test[:,2]=YYpre_so2[:,idx]
           inputX_test[:,3]=YYpre_no2[:,idx]
           inputX_test[:,4]=YYpre_co[:,idx]
           inputX_test[:,5]=YYpre_o3[:,idx]
           inputX_test[:,6]=YYpre_vis[:,idx]
           inputX_test[:,7]=YYpre_rh2[:,idx]
           inputX_test[:,8]=YYpre_t2[:,idx]
           inputX_test[:,9]=YYpre_u10[:,idx]
           inputX_test[:,10]=YYpre_v10[:,idx]
           inputX_test[:,11]=YYpre_pblh[:,idx]
           inputX_test[:,12]=YYpre_CLDFRA[:,idx]

           #########
           ######### time-lagged
           inputX_test = add_time_lags(inputX_test, lags)
           print("size of the new inputX:", inputX_test.shape)
           
           ######### remove the first 24h data, that's data in dayP1
           inputX_test = inputX_test[24::,:]
           print("size of the new inputX again:", inputX_test.shape)

           ########
           ########
           CitiesINFO(city,netpath,inputX_test,outpath,pallhourstr,dayCstrUTC) 
    
    ############################
    ############################
    ##########
    utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
    print('finised of running AI_LSTM_airQ_PredictionX for all needed citie at utc='+utcnow)
    ##########

##############################################
##############################################
############################
########
########
netpath="/data/yewu_RMAPSCHEM_MRv2/AI_TimeSeries/nets_tmp/LSTM"
figpath=netpath
########
RMAPSChemData="/data/Data4AI/RMAPSChem_prediction"

#########
######### read cityINFO
CityName = sio.loadmat(RMAPSChemData+'/CnameE.mat')
CityNameE= CityName['CnameE']


##############################################
############################################## only for the current day
##############################################
#dayX = datetime.datetime.utcnow() - datetime.timedelta(1) + datetime.timedelta(8/24)
beginDay = '20230731'
endDay = '20231230'
alldays = daysRange(beginDay,endDay)

#########
for dd in alldays:
    utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
    print('start working for '+dd+' at utc='+utcnow)
    ########## 
    ########## VIP
    ##########    
    dayCstrUTC = dd+'12'
    dC = datetime.datetime.strptime(dd, "%Y%m%d")
    ###dS = dC- datetime.timedelta(1) + datetime.timedelta(1/24*24)
    dS = dC + datetime.timedelta(1/24*24)
    ###
    dE = dS + datetime.timedelta(1/24*240)
    ###
    beginHour = dS.strftime('%Y%m%d%H')
    endHour = dE.strftime('%Y%m%d%H')

    ##########
    pallhourstr=hoursRange(beginHour, endHour)
    print('dayCstrUTC='+dayCstrUTC)
    
    ########## 
    ########## VIP
    ##########      
    TimesINFO(netpath,dayCstrUTC,pallhourstr)        
    
    ########## 
############################
############################
##########
utcnow = datetime.datetime.utcnow().strftime('%Y-%m-%d-%H:%M:%S')
print('finised of running AI_LSTM_airQ_PredictionX for all needed citie at utc='+utcnow)
############################
############################
 
